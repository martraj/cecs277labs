package lab2;

public interface EmployeeInfo 
{
	
	final double FACULTY_MONTHLY_SALARY = 5000.0;
	final int STAFF_MONTHLY_HOURS_WORKED = 160;
	
	public double monthlyEarning();
}
